package interfaces;

public interface IAbout {

    public interface View {

        void goBack();

    }

    public interface Presenter {



        void onBack();


    }
}
